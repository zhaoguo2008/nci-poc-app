package lerrain.project.mshell.component;

/**
 * Created by lerrain on 2018/6/17.
 */

public interface OnSelectListener
{
    public void select(Object item);
}
