package com.polysoft.nci.face;

/**
 * Created by Thinkpad on 2018/7/8.
 */

public class FaceConstant {

    public static final String APPKEY = "99ec690e521a8438c6b8e7554b6831d6f151060e";
    public static final String RIMID = "3100508001";
    public static final String SP_NO = "1300508947";

    public static final String KEY_SP_NO = "sp_no";
    public static final String KEY_RIMID = "rimid";
    public static final String KEY_METHOD = "method";
    public static final String KEY_RECOGT_YPE = "recogType";
    public static final String KEY_SHOWGUIDEPAGE = "showGuidePage";
    public static final String KEY_REAL_NAME = "realName";
    public static final String KEY_IDCARD_NO = "idCardNo";
    public static final String KEY_EXUID = "exuid";
    public static final String KEY_REQ_ID = "reqid";
    public static final String KEY_APPKEY = "key";
    public static final String KEY_SIGN = "sign";
    public static final String KEY_SP_PARAMS = "spParams";



}
