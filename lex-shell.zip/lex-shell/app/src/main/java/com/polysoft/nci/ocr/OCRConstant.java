package com.polysoft.nci.ocr;

import android.os.Environment;

public class OCRConstant {

	public static final String APP_KEY = "eN4UW5K8QN92rD8Ce62Wb2yM";
//	public static final String APP_KEY = "g1C33YUB83AC6HPF3X5EDr21";

	public static final int CALL_OCR_CODE = 1221212;
	
	public static final String OCR_IMAGE_PATH = Environment.getExternalStorageDirectory() + "/nci/save/photo/ocr.jpg";
}
