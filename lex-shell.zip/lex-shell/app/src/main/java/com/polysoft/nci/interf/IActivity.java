package com.polysoft.nci.interf;

import android.app.Activity;

public interface IActivity extends IStartActivity {

	public Activity getActivity();
	
}
