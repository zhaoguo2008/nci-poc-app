package com.polysoft.nci.interf;

import android.content.Intent;

public interface IActivityResult {

	public void onActivityResult(int requestCode, int resultCode, Intent data);

}
