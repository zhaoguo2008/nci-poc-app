package com.polysoft.nci.ocr;

public interface IOCRScript {

	public void buildObjData(String flag, String bitmapStr, OCRData ocr);
}
