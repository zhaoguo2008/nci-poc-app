package com.polysoft.nci.interf;

/**
 * Created by Thinkpad on 2018/7/8.
 */

public interface IJavaScript<T> {
    public void callJavaScript(String flag, T data);
}
