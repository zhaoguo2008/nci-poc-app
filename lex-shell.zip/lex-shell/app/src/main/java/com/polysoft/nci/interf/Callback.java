package com.polysoft.nci.interf;

public interface Callback<T> {

	public void onResult(T result);
}
